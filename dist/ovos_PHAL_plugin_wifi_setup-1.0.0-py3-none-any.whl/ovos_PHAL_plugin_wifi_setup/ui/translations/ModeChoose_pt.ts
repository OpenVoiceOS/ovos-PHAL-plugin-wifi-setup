<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
    <context>
        <name>ModeChoose</name>
        <message>
            <location line="34" filename="../ModeChoose.qml"/>
            <source>Setup Networking</source>
            <translation>configuração de rede</translation>
        </message>
        <message>
            <location line="169" filename="../ModeChoose.qml"/>
            <source>Skip Setup</source>
            <translation>Saltar configuração</translation>
        </message>
    </context>
</TS>
