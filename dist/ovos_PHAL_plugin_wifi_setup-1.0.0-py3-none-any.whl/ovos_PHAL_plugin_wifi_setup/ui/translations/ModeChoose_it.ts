<?xml version='1.0' encoding='utf-8'?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
    <context>
        <name>ModeChoose</name>
        <message>
            <location line="34" filename="../ModeChoose.qml"/>
            <source>Setup Networking</source>
            <translation>Configurazione della rete</translation>
        </message>
        <message>
            <location line="169" filename="../ModeChoose.qml"/>
            <source>Skip Setup</source>
            <translation>Salta configurazione</translation>
        </message>
    </context>
</TS>
